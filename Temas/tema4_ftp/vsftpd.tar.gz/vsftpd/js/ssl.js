
<!-- 

function validate_form() {

if (document.formular.authority.value=="") { 
  alert("Please fill in a Authority Name");
  return false;
}

if (document.formular.email.value.indexOf('.')==-1) { 
  alert ("This is an invalid e-mail address.");
  return false;
}

if (document.formular.email.value.indexOf('@')==-1) {
  alert ("This is an invalid e-mail address.");
  return false;
}

if (document.formular.organization.value=="") {
 alert("Please fill in a Organization.");
 return false;
}

if (document.formular.departement.value=="") {
 alert ("Please fill in a departement.");
 return false;
}

if (document.formular.city.value=="") {
 alert ("Please fill in your city.");
 return false;
 }

if (document.formular.state.value=="") {
 alert ("Please fill in your state.");
 return false;
}

if (document.formular.country.value=="") {
 alert ("Please fill in your country code - normally 2 BIG letters.");
 return false;
}

}

-->