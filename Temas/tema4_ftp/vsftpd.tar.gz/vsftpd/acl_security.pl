
# acl_security_form(&options)
# Output HTML for editing security options for the apache module
sub acl_security_form
{

## Here you have to fill in the code for output

}

# acl_security_save(&options)
# Parse the form for security options for the apache module
sub acl_security_save
{

## here you have to fill in the handling code for the saving the ACL

}